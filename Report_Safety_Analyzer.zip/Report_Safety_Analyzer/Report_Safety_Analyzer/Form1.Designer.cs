﻿namespace Report_Safety_Analyzer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            Reports_Text_Box = new RichTextBox();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(415, 657);
            button1.Name = "button1";
            button1.Size = new Size(203, 94);
            button1.TabIndex = 0;
            button1.Text = "Calculate";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Reports_Text_Box
            // 
            Reports_Text_Box.Location = new Point(27, 34);
            Reports_Text_Box.Name = "Reports_Text_Box";
            Reports_Text_Box.Size = new Size(330, 717);
            Reports_Text_Box.TabIndex = 1;
            Reports_Text_Box.Text = "";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(671, 792);
            Controls.Add(Reports_Text_Box);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private RichTextBox Reports_Text_Box;
    }
}
